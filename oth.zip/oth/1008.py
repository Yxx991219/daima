#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@Time    : 2019/10/8 9:15
@Author  : YL
@Site    : 
@File    : 1008.py
@Software: PyCharm
'''
import matplotlib.pyplot as plt
import numpy as np
from xlrd import open_workbook

x_data = []
y_data = []
y_data1 = []

#wb = open_workbook('seller-time/seller_time.xlsx')
#wb = open_workbook('step-time/step_time.xlsx')
#wb = open_workbook('xiaoguo/gvms.xlsx')
#wb = open_workbook('xiaoguo/f_a.xlsx')
#wb = open_workbook('xiaoguo/f_b.xlsx')
#wb = open_workbook('xiaoguo/f_c.xlsx')
wb = open_workbook('xiaoguo/f_11.xlsx')



for s in wb.sheets():
    # print('Sheet:', s.name)
    for row in range(s.nrows):
        # print('the row is:', row)
        values = []
        for col in range(s.ncols):
            values.append(s.cell(row, col).value)
        # print(values)
        x_data.append(values[0])
        y_data.append(values[1])
        y_data1.append(values[2])
print(x_data)
print(y_data)
print(y_data1)
plt.plot(x_data, y_data, marker='^', mec='r', mfc='w', label='DDPG-PMD')
plt.plot(x_data, y_data1, marker='.', mec='r', mfc='w', label='DDPG-ANP')
plt.xticks(x_data[::3])
#plt.xticks(x_data[::])
plt.title('')
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus'] = False
plt.legend()

#plt.xlabel('Number of sellers')
# plt.xlabel('Number of maximum time steps')
# plt.ylabel('Runtime(s)/episode')

# plt.xlabel('t')
# plt.ylabel('fake transactions')

plt.xlabel('t')
plt.ylabel('Number of fake sellers')

#plt.xlabel('Episode')
#plt.ylabel('Platform utility')
plt.show()
