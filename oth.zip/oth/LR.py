import numpy as np
import csv
from sklearn.linear_model import LinearRegression

n=150

def loadDates():
    X = []
    y = []
    # price  punish 收益 r f cr
    xx = []
    #for i in range(0, 999):  #每一类卖方分开，分别回归
    for i in range(1000, 1999):
    #for i in range(2000, 2999):
    #for i in range(3000, 3999):
        #print(i)
        file_path = "./data/per_{}.csv".format(i + 1)#读取数据的文件
        with open(file_path, encoding='utf-8') as f:#读取数据
            csv_reader = csv.reader(f)
            for j, row in enumerate(csv_reader):#按照行来读每条数据
                #以下的意思是前一个的数据的所有字段作为X值，下一条数据的造假作为预测的造假，即y值
                #if j > 0:#
                    #nums = row[0].split()
                    #print(nums[4])
                    #y.append(float(nums[4]))
                if j < 100:       #取每个用户的100条数据作为训练数据
                    nums = row[0].split()
                    if (float(nums[4]) + float(nums[3])) == 0: # 与数据关联
                        sk2 = round(float(nums[4]) / 0.001, 2)
                    else:
                        sk2 = round(float(nums[4])/(float(nums[4]) + float(nums[3])), 2)
                    xx.append(float(nums[4]))
                    X.append(np.array([float(nums[0]), float(nums[1]), float(nums[2]), float(nums[3]), sk2]))
                    y.append(float(nums[4]))
                if j == 100:
                    break

            #print(xx, len(xx))
            #print(y, len(y))
            #break
    return np.array(X), np.array(y)

def LR_fun(X, y):
    lin_reg = LinearRegression()#线性回归计算
    lin_reg.fit(X, y)# 上一个函数得到的数据X和y

    return lin_reg.coef_, lin_reg.intercept_#返回权重和偏置

def Return_W_and_b():#接口函数，为了将得到的权重和偏直用到别的文件中
    X, y =loadDates()
    w, b = LR_fun(X, y)

    return w, b

#Return_W_and_b(1001,1020)
#Return_W_and_b()